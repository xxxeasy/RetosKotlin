package com.example.firebaseloginapp

import android.R
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.example.firebaseloginapp.databinding.ActivityConsultaBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_consulta.*

class ConsultaActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    private lateinit var binding: ActivityConsultaBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConsultaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listaPaises = ArrayList<String>()
        listaPaises.add("Selecciona país...")
        val paisData = HashMap<String, Any>()
        val listaCiudades = ArrayList<String>()
        listaCiudades.add("Selecciona una ciudad...")
        val ciudadData = HashMap<String, Any>()
        val monumentoData = HashMap<String, String>()

        val paisesSpinner = binding.spinner
        val ciudadesSpinner = binding.spinner2

        db.collection("paises").get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    listaPaises.add(document.get("nombre").toString())
                    Log.d("Paises", document.get("nombre") as String)
                }
            }

        val paisesAdapter: ArrayAdapter<String> =
            object : ArrayAdapter<String>(this, R.layout.simple_spinner_item, listaPaises) {
                override fun isEnabled(position: Int): Boolean {
                    return position != 0
                }
            }
        paisesAdapter.setDropDownViewResource(R.layout.simple_spinner_item)
        paisesSpinner.adapter = paisesAdapter

        val ciudadesAdapter: ArrayAdapter<String> =
            object : ArrayAdapter<String>(this, R.layout.simple_spinner_item, listaCiudades) {
                override fun isEnabled(position: Int): Boolean {
                    return position != 0
                }
            }
        ciudadesAdapter.setDropDownViewResource(R.layout.simple_spinner_item)
        ciudadesSpinner.adapter = ciudadesAdapter

        paisesSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p0: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position != 0) {
                        val paisSelected = listaPaises[position]
                        db.collection("paises").whereEqualTo("nombre", paisSelected).get()
                            .addOnSuccessListener { result ->
                                for (document in result) {
                                    paisData.put("id", document.id)
                                    paisData.put("nombre", document.get("nombre") as String)
                                    paisData.put("poblacion", document.get("poblacion") as Long)
                                }
                                listaCiudades.clear()
                                listaCiudades.add("Selecciona una ciudad...")
                                db.collection("ciudades").whereEqualTo("cod_pais", paisData.get("id")).get()
                                    .addOnSuccessListener { result ->
                                        for (document in result) {
                                            listaCiudades.add(document.get("nombre") as String)
                                        }
                                    }

                                val ciudadesAdapter =
                                    object : ArrayAdapter<String>(view!!.context, R.layout.simple_spinner_item, listaCiudades) {
                                        override fun isEnabled(position: Int): Boolean {
                                            return position != 0
                                        }
                                    }
                                ciudadesAdapter.setDropDownViewResource(R.layout.simple_spinner_item)
                                ciudadesSpinner.adapter = ciudadesAdapter
                            }
                        }
                    }

                override fun onNothingSelected(p0: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }
            }

            ciudadesSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p0: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position != 0) {
                        val ciudadSelected = listaCiudades[position]
                        db.collection("ciudades").whereEqualTo("nombre", ciudadSelected).get()
                            .addOnSuccessListener { result ->
                                for (document in result) {
                                    ciudadData.put("id", document.id)
                                    ciudadData.put("nombre", document.get("nombre") as String)
                                    ciudadData.put("poblacion", document.get("poblacion") as String)
                                }

                                db.collection("monumentos").whereEqualTo("cod_poblacion", ciudadData.get("id")).get()
                                    .addOnSuccessListener { result ->
                                        for (document in result) {
                                            monumentoData.put("id", document.id)
                                            monumentoData.put("cod_poblacion", document.get("cod_poblacion") as String)
                                            monumentoData.put("nombre", document.get("nombre") as String)
                                        }

                                        tv.text = paisData.get("poblacion").toString()
                                        tv2.text = ciudadData.get("nombre").toString()
                                        tv3.text = ((ciudadData.get("poblacion") as Int / paisData.get("poblacion") as Int) * 100).toString()
                                        tv4.text = ciudadData.get("poblacion").toString()
                                        tv5.text = monumentoData.get("nombre").toString()

                                    }
                            }
                    }
                }

                override fun onNothingSelected(p0: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }
            }

    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        TODO("Not yet implemented")
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}