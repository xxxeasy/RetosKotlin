package com.example.retofinal

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.retofinal.R.drawable
import com.example.retofinal.ui.theme.RetoFinalTheme

data class Person(
    val id: Int,
    val tripulacion: String,
    val nombre: String,
    val imageUrl: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val persons = arrayListOf<Person>()
        persons.add(
            Person(
                id = 1,
                tripulacion = "Piratas de Shirohigue",
                nombre = "Ace",
                imageUrl = drawable.ace
            )
        )
        persons.add(
            Person(
                id = 2,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Luffy",
                imageUrl = drawable.luffys_flag_2
            )
        )
        persons.add(
            Person(
                id = 3,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Zoro",
                imageUrl = drawable.zoro
            )
        )
        persons.add(
            Person(
                id = 4,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Nami",
                imageUrl = drawable.nami
            )
        )
        persons.add(
            Person(
                id = 5,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Ussop",
                imageUrl = drawable.ussop
            )
        )
        persons.add(
            Person(
                id = 6,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Sanji",
                imageUrl = drawable.sanji
            )
        )
        persons.add(
            Person(
                id = 7,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Chopper",
                imageUrl = drawable.chopper
            )
        )
        persons.add(
            Person(
                id = 8,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Robin",
                imageUrl = drawable.nico
            )
        )
        persons.add(
            Person(
                id = 9,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Franky",
                imageUrl = drawable.franck
            )
        )
        persons.add(
            Person(
                id = 10,
                tripulacion = "Piratas de los Sombrero de paja",
                nombre = "Brook",
                imageUrl = drawable.brook
            )
        )
        persons.add(
            Person(
                id = 11,
                tripulacion = "Princesa de Arabasta",
                nombre = "Vivi",
                imageUrl = drawable.vivi
            )
        )
        persons.add(
            Person(
                id = 12,
                tripulacion = "Piratas del Pelirrojo",
                nombre = "Shanks",
                imageUrl = drawable.shanks
            )
        )
        persons.add(
            Person(
                id = 13,
                tripulacion = "Piratas de Buggy",
                nombre = "Buggy",
                imageUrl = drawable.buggy
            )
        )
        persons.add(
            Person(
                id = 14,
                tripulacion = "Piratas de Shirohigue",
                nombre = "Barbablanca",
                imageUrl = drawable.barbe_blanche
            )
        )
        persons.add(
            Person(
                id = 15,
                tripulacion = "Gobierno Mundial",
                nombre = "Im",
                imageUrl = drawable.gouvernement_mondiale
            )
        )

        setContent {
            RetoFinalTheme {
                // A surface container using the 'background' color from the theme
                Surface(color = MaterialTheme.colors.background) {
                    LazyColumnClickable(persons) {
                        val intent = Intent(this, MostrarCarta::class.java)
                        intent.putExtra("Nombre", it.nombre)
                        intent.putExtra("Tripulacion", it.tripulacion)
                        intent.putExtra("Imagen", it.imageUrl)
                        startActivity(intent)
                    }
                }
            }
        }
    }
}

@Composable
fun LazyColumnClickable(persons: List<Person>, selectedPerson: (Person) -> Unit) {
    LazyColumn{
        items(
            items = persons,
            itemContent = {
                ListItem(it, selectedPerson)
            }
        )
    }
}

@Composable
fun ImageLoader(imageUrl : Int){
    Image(
        painterResource(imageUrl),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(120.dp)
    )
}

@Composable
fun ListItem(person: Person, selectedPerson: (Person) -> Unit){
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .clickable { selectedPerson(person) },
        elevation = 8.dp
    ) {
        Row() {
            ImageLoader(person.imageUrl)
            Spacer(modifier = Modifier.width(20.dp))
            Text(
                text = "${person.nombre} ",
                style = MaterialTheme.typography.h5,
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }
    }
}