package com.example.retofinal

import android.os.Bundle
import android.os.PersistableBundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.retofinal.ui.theme.RetoFinalTheme

class MostrarCarta : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            RetoFinalTheme {
                Surface(color = MaterialTheme.colors.background, ) {
                    Informacion(intent.getIntExtra("Imagen", 0), intent.getStringExtra("Nombre").toString(), intent.getStringExtra("Tripulacion").toString())
                }
            }
        }
    }
}

@Composable
fun Informacion(imagen: Int, nombre: String, tripulacion: String){
    Card(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth(),
        elevation = 8.dp
    ) {
        Column() {
            ImagenLoader(imagen)
            Spacer(modifier = Modifier.width(20.dp))
            Text(
                text = "${nombre} ",
                style = MaterialTheme.typography.h2,
                modifier = Modifier.padding(8.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Tripulación: ${tripulacion} ",
                style = MaterialTheme.typography.h2,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
fun ImagenLoader(imagen: Int) {
    Image(
        painterResource(imagen),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(120.dp)
    )
}